#Este programa genera la salida final
#La salida queda en  /work/lineademuerte_entregar_Austral.txt  , lineademuerte_probabilidades_Austral.txt  y lineademuerte_importancia_Austral.txt
#Este programa necesita para correr 4vCPU y 40GB de RAM
#para correr se merece una digna maquina Inmortal
#Correrlo desde RStudio



#Atencion, se trabaja solamente con los archivos  *_dias.txt
#No se crea ninguna variable en el mismo mes
#No se crea ninguna variable historica, ni maximos, minimos, tendencias, etc
#No se imputan nulos, no se quitan outliers
#No se crean variables que sean predicciones de modelos
#No se hace undersampling, se trabaja con todos los datos
#No se optimiza la probabilidad de corte, se deja en la original de 0.025
#No se trabaja con clase_binaria2  positivos = { BAJA+1, BAJA+2 }
#No se ajusta por inflacion
#No se traen variables externas como el valor mensual del dolar
#No se hace stacking de modelos al final
#... una autentica linea de muerte de personalidad vegana ... 


#Lo unico importante de este programa es


switch ( Sys.info()[['sysname']],
         Windows = { directory.work     <-  "M:\\work\\"
                     directory.datasets <-  "M:\\datasets\\"
                   },
         Darwin  = { directory.work     <-  "~/dm/work/"
                     directory.datasets <-  "~/dm/datasets/"
                   },
         Linux   = { directory.work     <-  "~/cloud/cloud1/work/"
                     directory.datasets <-  "~/cloud/cloud1/datasets/"
                   }
        )



library( "xgboost" )
library( "Matrix" ) 

library( "data.table" )



kcampos_separador     <-  "\t"
kcampo_id             <-  "numero_de_cliente"
kclase_nomcampo       <-  "clase_ternaria"
kclase_valor_positivo <-  "BAJA+2"
kcampos_a_borrar      <-  c( kcampo_id )



karchivo_salida      <-  "lineademuerte_entregar_Austral.txt"
karchivo_probs       <-  "lineademuerte_probabilidades_Austral.txt"
karchivo_importancia <-  "lineademuerte_importancia_Austral.txt"


#aplico el modelo a junio, que NO tiene clase
#la decision de entrenar en 10 meses se obtuvo de los testeos hechos sobre junio del 2018

#------------------------------------------------------------------------------
#debe tenerse en cuenta que para 201906 la clase esta VACIA
#por lo que NO se puede calcular la ganancia
#esta vez, realmente estamos prediciendo el futuro
#es un salto al vacio

#cargo los datasets

setwd(  directory.datasets )

dataset   <-   fread( cmd="cat paquete_premium_dias.txt" )

#dejo la clsae en 0,1
dataset[  , clase_ternaria := as.integer(clase_ternaria=="BAJA+2") ]

#entreno en 10 meses,  periodo  [ 201807, 201904 ]
dgeneracion  <-   xgb.DMatrix( data  = data.matrix( dataset[ foto_mes>=201807 & foto_mes<=201904 , !c("numero_de_cliente","clase_ternaria"), with=FALSE]),
                               label = dataset[ foto_mes>=201807 & foto_mes<=201904, clase_ternaria ], 
                               missing=NA 
                              )

#aplico a los datos de 201906, que tienen la clase varia
daplicacion  <-   xgb.DMatrix( data  = data.matrix( dataset[ foto_mes==201906, !c("numero_de_cliente","clase_ternaria"), with=FALSE]),
                               label = dataset[ foto_mes==201906, clase_ternaria ], 
                               missing=NA 
                              )
#---------------------

#Finalmente, llamo al XGBoost
#notar lo frugal de los hiperparametros

#mi querida random seed
set.seed( 102191  )

modelo = xgb.train( 
               data = dgeneracion,
               objective="binary:logistic",
               nrounds=130, 
               base_score=mean(getinfo(dgeneracion, "label") ),
               colsample_bytree=0.30, 
               eta=0.1, 
               max_bin=31, 
               tree_method='hist',
               verbosity=2
              )


#aplico el modelo a datos nuevos
aplicacion_prediccion  <- predict(  modelo, daplicacion )

#uno las columnas de numero_de_cliente y la probabilidad recien calculada
prediccion_final  <-  as.data.table( cbind(  dataset[ foto_mes==201906, c("numero_de_cliente","clase_ternaria") ], aplicacion_prediccion ) )

#le doy nombre a las columnas
colnames( prediccion_final )  <-  c( "numero_de_cliente", "clase01", "prob_positivo" )

#para calcular la ganancia, cuando se corre para meses del pasado
#sum(  prediccion_final[ prob_positivo>0.025,   ifelse( clase01==1, 19500, -500) ] )


#grabo todas las probabilidad, simplemente para tenerlo
setwd(  directory.work )
fwrite( prediccion_final[ order(-prob_positivo) ], 
        file=karchivo_probs, row.names=FALSE, col.names=TRUE, quote=FALSE, sep="\t", eol = "\r\n")



#Ahora grabo la salida que debo entregar en la materia, que son solamente los ids
#me quedo solamente con los numero_de_cliente donde probabilidad > 0.025
setwd(  directory.work )
fwrite( as.data.table( prediccion_final[ prob_positivo > 0.025  , get(kcampo_id) ] ), 
        file=karchivo_salida, row.names=FALSE, col.names=FALSE, quote=FALSE, sep="\t", eol = "\r\n")



#por el mismo precio, grabo la importancia de las variables
write.table(  xgb.importance( model = modelo )
              , file= karchivo_importancia
              , row.names=FALSE
              , col.names=TRUE
              , quote=FALSE
              , sep="\t"
              , eol = "\r\n"
           )

